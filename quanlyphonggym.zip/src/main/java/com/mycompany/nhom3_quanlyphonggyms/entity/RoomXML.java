/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nhom3_quanlyphonggyms.entity;

import java.util.List;

/**
 *
 * @author Admin
 */
public class RoomXML {
    private List<Room> room;
    public List<Room> getRoom() {
        return room;
    }
    
    public void setRoom(List<Room> room) {
        this.room = room;
    }
    
}
