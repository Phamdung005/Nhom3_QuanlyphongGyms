# java-swing-custom-chart
Date : 15/09/2021<br/>
How to coding in java
visit my youtube : https://www.youtube.com/c/HelloWorld-Raven/featured
<br/><br/>
- Chart 001

![2021-09-15_214438](https://user-images.githubusercontent.com/58245926/133459124-a32ac177-088d-4276-a037-7eeaa38f6eb8.png)

![2021-12-28_215511](https://user-images.githubusercontent.com/58245926/147578757-87d2c369-47fa-412c-a69e-3382836acf02.png)

![image](https://user-images.githubusercontent.com/58245926/147578787-7a8b3c50-e365-4715-ab8b-bdf6763f9236.png)

![image](https://user-images.githubusercontent.com/58245926/147578861-5af58207-8bc0-48b3-a30e-5aaf4b97d594.png)

![image](https://user-images.githubusercontent.com/58245926/147578998-e90b0564-73fe-484b-8708-2dc3612887fc.png)

![image](https://user-images.githubusercontent.com/58245926/147579033-7aa4c8f3-32b8-4b05-8206-82ca4639a698.png)
